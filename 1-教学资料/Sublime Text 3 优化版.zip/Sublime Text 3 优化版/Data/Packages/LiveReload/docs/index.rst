.. LiveReload for Sublime Text 2 documentation master file, created by
   sphinx-quickstart on Mon Feb 18 09:38:07 2013.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

LiveReload for Sublime Text
=========================================================

Plugins api
****************************
.. autoclass:: PluginAPI.PluginClass
   :members:
   :show-inheritance:

Decorators:

.. automodule:: LiveReload
   :members:
   :show-inheritance:

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

